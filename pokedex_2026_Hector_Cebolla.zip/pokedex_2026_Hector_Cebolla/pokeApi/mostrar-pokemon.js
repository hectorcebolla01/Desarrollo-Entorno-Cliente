import { getPokemonById } from "./api.js";
import { mostrarInfo } from "./info-panel.js";

export const TOTAL = 1025;

let pokeName = document.getElementById("poke-name");
let pokeImg = document.getElementById("poke-img");
let prevName = document.getElementById("prev-name");
let nextName = document.getElementById("next-name");

export let getPrevId = (id) => (id === 1 ? TOTAL : id - 1);
export let getNextId = (id) => (id === TOTAL ? 1 : id + 1);

export let mostrarPokemon = async (id) => {
    try {
        let [actual, anterior, siguiente] = await Promise.all([
            getPokemonById(id),
            getPokemonById(getPrevId(id)),
            getPokemonById(getNextId(id))
        ]);

        pokeName.textContent = `ID: ${actual.id} · ${actual.name}`;
        pokeImg.src = actual.sprites.front_default;
        pokeImg.alt = actual.name;
        prevName.textContent = anterior.name;
        nextName.textContent = siguiente.name;

        await mostrarInfo(actual);

        return actual.id; // main lo usa para saber cuál es el actual
    } catch (error) {
        console.error("Error:", error);
        pokeName.textContent = "ERROR: " + error.message;
        return id;
    }
};