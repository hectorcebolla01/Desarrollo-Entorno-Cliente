let getAllPokemons = async () => {
    let pokemonData = await fetch("https://pokeapi.co/api/v2/pokemon");

    pokemonData = await pokemonData.json();

    return pokemonData;
}

let getPokemonByName = async (name) => {
    /* return pokemon */

    let pokemonData = await fetch("https://pokeapi.co/api/v2/pokemon/" + name);

    pokemonData = await pokemonData.json();

    return pokemonData;
}

let getPokemonById = async (id) => {
    /* return pokemon */

    let pokemonData = await fetch("https://pokeapi.co/api/v2/pokemon/" + id);

    pokemonData = await pokemonData.json();

    return pokemonData;
}

let getPokemonsAbility = async (abilityName) => {
    let pokemonData = await fetch ("https://pokeapi.co/api/v2/ability/" + abilityName);

    pokemonData = await pokemonData.json();

    return pokemonData;
};

let getPokemonType = async (abilityName) => {
    let pokemonData = await fetch ("https://pokeapi.co/api/v2/type/" + abilityName);

    pokemonData = await pokemonData.json();

    return pokemonData;
};

let getPokemonSpecies = async (name) => {
    let pokemonData = await fetch ("https://pokeapi.co/api/v2/pokemon-species/" + name);

    pokemonData = await pokemonData.json();

    return pokemonData;
}

let getPokemonGeneration = async (generationName) => {
    let pokemonData = await fetch("https://pokeapi.co/api/v2/generation/" + generationName);
    return await pokemonData.json();
}

let getPokemonList = async () => {
    let pokemonData = await fetch("https://pokeapi.co/api/v2/pokemon?limit=1025");
    pokemonData = await pokemonData.json();
    return pokemonData.results; 
}



export {getAllPokemons, getPokemonById, getPokemonsAbility, getPokemonType, getPokemonSpecies, getPokemonByName, getPokemonGeneration, getPokemonList}