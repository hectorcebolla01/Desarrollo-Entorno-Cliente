import { getPokemonSpecies } from "./api.js";
import { getPokemonGeneration } from "./api.js";

let pokeNumber = document.getElementById("poke-number");
let pokeName1 = document.getElementById("poke-name1");
let pokeSpecies = document.getElementById("poke-speices");
let pokeHeight = document.getElementById("poke-height");
let pokeWeight = document.getElementById("poke-weight");
let pokeHP = document.getElementById("poke-hp");
let pokeHPBar = document.getElementById("poke-hp-bar");
let pokeAttack = document.getElementById("poke-attack")
let pokeAttackBAr = document.getElementById("poke-attack-bar")
let pokeDefense = document.getElementById("poke-defense");
let pokeDefenseBar = document.getElementById("poke-defense-bar");
let pokeSpeed = document.getElementById("poke-speed");
let pokeSpeedBar = document.getElementById("poke-speed-bar");
let pokeEncounters = document.getElementById("poke-encounters");
let pokeRegion = document.getElementById("poke-region");

const MAX_STAT_HP = 255;
const MAX_STAT_ATTACK = 190;
const MAX_STAT_DEFENSE = 230;
const MAX_STAT_SPEED = 200;

let capitalizar = (texto) => texto.charAt(0).toUpperCase() + texto.slice(1);

export let mostrarInfo = async (pokemon) => {
    let hp = pokemon.stats.find(item => item.stat.name === "hp").base_stat;
    let attack = pokemon.stats.find(item => item.stat.name === "attack").base_stat;
    let defense = pokemon.stats.find(item => item.stat.name === "defense").base_stat;
    let speed = pokemon.stats.find(item => item.stat.name === "speed").base_stat;

    pokeNumber.textContent = "#" + String(pokemon.id).padStart(3, "0");
    pokeName1.textContent = capitalizar(pokemon.name);
    pokeHeight.textContent = pokemon.height / 10 + " m";
    pokeWeight.textContent = pokemon.weight / 10 + "kg";
    pokeHP.textContent = hp;
    pokeHPBar.style.width = (hp / MAX_STAT_HP * 100) + "%";
    pokeAttack.textContent = attack;
    pokeAttackBAr.style.width = (attack / MAX_STAT_ATTACK * 100) + "%";
    pokeDefense.textContent = defense;
    pokeDefenseBar.style.width = (defense / MAX_STAT_DEFENSE * 100) + "%";
    pokeSpeed.textContent = speed;
    pokeSpeedBar.style.width = (speed / MAX_STAT_SPEED * 100) + "%";


    try {
        let especie = await getPokemonSpecies(pokemon.id);

        // Especie ("Pokémon Ratón"), en español y si no en inglés
        let genus =
            especie.genera.find((g) => g.language.name === "es") ||
            especie.genera.find((g) => g.language.name === "en");
        pokeSpecies.textContent = genus ? genus.genus.toUpperCase() : "DESCONOCIDA";

        // Descripción de la Pokédex
        let entrada =
            especie.flavor_text_entries.find((t) => t.language.name === "es") ||
            especie.flavor_text_entries.find((t) => t.language.name === "en");
        pokeEncounters.textContent = entrada
            ? entrada.flavor_text.replace(/[\n\f]/g, " ")
            : "SIN DESCRIPCIÓN";

        // Región de su generación (generation-i -> kanto)
        let generacion = await getPokemonGeneration(especie.generation.name);
        pokeRegion.textContent =
            "REGISTRO OFICIAL DE " + generacion.main_region.name.toUpperCase();
    } catch (error) {
        console.error("Error al cargar la especie o la generación:", error);
        pokeSpecies.textContent = "DESCONOCIDA";
        pokeEncounters.textContent = "SIN DESCRIPCIÓN";
        pokeRegion.textContent = "REGISTRO OFICIAL";
    }



};