import { mostrarPokemon, getPrevId, getNextId, TOTAL } from "./pokeApi/mostrar-pokemon.js";
import { iniciarCatalogo } from "./catalogo.js";

iniciarCatalogo((id) => cargar(id));

let btnPrev = document.getElementById("poke-prev");
let btnNext = document.getElementById("poke-next");
let codForm = document.getElementById("poke-cod");
let codDisplay = document.getElementById("poke-cod-display");

let currentId = 1;
let codigo = "";

let cargar = async (id) => {
    currentId = await mostrarPokemon(id);
};

btnPrev.addEventListener("click", () => cargar(getPrevId(currentId)));
btnNext.addEventListener("click", () => cargar(getNextId(currentId)));

// Teclado numérico: un solo listener para todos los botones
codForm.addEventListener("click", (e) => {
    let boton = e.target.closest("button");
    if (!boton) return;

    let accion = boton.dataset.accion;

    if (accion === "borrar") {
        codigo = "";
    } else if (accion === "ok") {
        let id = Number(codigo);
        if (id >= 1 && id <= TOTAL) {
            cargar(id);
            codigo = "";
        } else {
            codDisplay.textContent = "ERROR";
            codigo = "";
            return;
        }
    } else {
        let nuevo = codigo + boton.textContent.trim();

        // Si supera 4 cifras o el máximo de Pokémon, se reinicia
        if (nuevo.length > 4 || Number(nuevo) > TOTAL) {
            codigo = "";
        } else {
            codigo = nuevo;
        }
    }

    codDisplay.textContent = codigo || "----";
});

cargar(currentId);