import { getPokemonList } from "./pokeApi/api.js";

const REGIONES = {
    kanto:  { nombre: "Kanto",  inicio: 1,   fin: 151 },
    johto:  { nombre: "Johto",  inicio: 152, fin: 251 },
    hoenn:  { nombre: "Hoenn",  inicio: 252, fin: 386 },
    sinnoh: { nombre: "Sinnoh", inicio: 387, fin: 493 },
    teselia:{ nombre: "Teselia",inicio: 494, fin: 649 },
    kalos:  { nombre: "Kalos",  inicio: 650, fin: 721 },
    alola:  { nombre: "Alola",  inicio: 722, fin: 809 },
    galar:  { nombre: "Galar",  inicio: 810, fin: 905 },
    paldea: { nombre: "Paldea", inicio: 906, fin: 1025 }
};

let selectRegion = document.getElementById("catalog-region");
let rangoEl = document.getElementById("catalog-rango");
let totalEl = document.getElementById("catalog-total");
let catalogo = document.querySelector(".catalog");

let listaPokemon = null; // se carga una sola vez

let formatearId = (id) => "#" + String(id).padStart(3, "0");

let imagenUrl = (id) =>
    `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`;

let pintarRegion = async (clave) => {
    let region = REGIONES[clave];

    if (!region) {
        catalogo.innerHTML = "";
        rangoEl.textContent = "";
        totalEl.textContent = "0 ESPECÍMENES";
        return;
    }

    let total = region.fin - region.inicio + 1;
    rangoEl.textContent = `(${formatearId(region.inicio)} - ${formatearId(region.fin)})`;
    totalEl.textContent = `${total} ESPECÍMENES`;
    catalogo.innerHTML = '<p class="text-white small">Cargando...</p>';

    try {
        if (!listaPokemon) listaPokemon = await getPokemonList();

        let html = "";
        for (let id = region.inicio; id <= region.fin; id++) {
            let nombre = listaPokemon[id - 1].name;
            html += `
                <div class="col-4 col-md-3">
                    <button type="button" class="btn dark-btn w-100 p-2 text-center" data-id="${id}">
                        <img src="${imagenUrl(id)}" class="img-fluid" loading="lazy" alt="${nombre}">
                        <small class="d-block">${formatearId(id)}</small>
                        <small class="d-block text-capitalize">${nombre}</small>
                    </button>
                </div>`;
        }
        catalogo.innerHTML = html;
    } catch (error) {
        console.error("Error al cargar el catálogo:", error);
        catalogo.innerHTML = '<p class="text-white small">No se pudo cargar el catálogo.</p>';
    }
};

export let iniciarCatalogo = (alSeleccionar) => {
    // Opciones del selector
    selectRegion.innerHTML =
        '<option value="">Elige región...</option>' +
        Object.entries(REGIONES)
            .map(([clave, r]) => `<option value="${clave}">${r.nombre}</option>`)
            .join("");

    selectRegion.addEventListener("change", () => pintarRegion(selectRegion.value));

    // Un solo listener para todas las tarjetas
    catalogo.addEventListener("click", (e) => {
        let tarjeta = e.target.closest("button[data-id]");
        if (!tarjeta) return;
        alSeleccionar(Number(tarjeta.dataset.id));
    });

    pintarRegion("");
    catalogo.innerHTML = '<p class="text-white small">Elige una región para ver el catálogo.</p>';
};